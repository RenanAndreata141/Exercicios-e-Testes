for l in range(1,21,1):
    A = int(input( " DIgite o valor de A"))
    B = int(input( " DIgite o valor de B"))
    C = int(input( " DIgite o valor de C"))

    if A > B and A > C:
        print( " A é o maior valor ")
    elif B > A and B > C:
        print( " B é o maior valor ")
    else:
        print( " C é o maior valor ")
