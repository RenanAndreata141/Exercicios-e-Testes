for numero in range(1,7,1):
    numero = int(input("Digite um valor inteiro: "))
    if(numero > 0):
        if( numero % 3 == 0):
          print("O seu número é multiplo de 3 e é positivo")
        else:
           print("O seu numero é maior que 0, mas n é multiplo de 3")

    elif(numero < 0):
        if( numero % 3 == 0):
          print("O seu número é multiplo de 3 e é negativo")
        else:
           print("O seu numero é menor que 0, mas n é multiplo de 3")
else:
   print("Fim")


