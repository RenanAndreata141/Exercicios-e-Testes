soma = 0
for i  in range(1,15,1):
    valor = float(input( " Digite seu valor "))
    soma += valor

media = soma / 15
print(" %0.2f " % (media))