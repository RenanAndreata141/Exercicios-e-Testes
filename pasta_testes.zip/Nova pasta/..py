nome = input("Digite um nome para o seu documento: \n")
arquivo = open(nome+".txt", 'w', encoding='utf-8')
loop = 1
lista = []
numero = 100
while(loop == 1):
    for i in range(101):
        lista.append(numero)
        numero -= 1

    lista_string = str(lista)
    arquivo.write(lista_string)
    arquivo.close()
    print("Gostaria de finalizar o processo: 0 para sim 1 para não")
    opcao = int(input("Digite aqui: \n"))
    if(opcao == 0):
        print("Processo finalizado, essa é a lista em decrescente: \n")
        print(lista)
        loop = 0
    elif(opcao == 1):
        print("Processo se repetira ate você finalizar")
    else:
        print("opção incorreta tenta novamente")

