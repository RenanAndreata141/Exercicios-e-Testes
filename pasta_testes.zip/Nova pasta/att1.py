for k in range(1,6,1):
    c = float(input("Digite uma temperatura em celsius: "))
    k = c + 273
    print("O seu valor em Kelvin é: %0.2f" % (k))
else:
    print("Fim")