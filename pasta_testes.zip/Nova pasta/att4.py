for n in range(1,21,1):
    N = int(input(" Digite o Numero:  "))

    if N %2 == 0:
        print( " Seu numero é par  ")
    else:
        print( " Seu numero e Impar")
