listaA = []
listaB = []

num = int(input("digite um numero \n"))

def tabuada():
    valor = []
    for i in range(1,11):
        valor.append(i*num)
    return valor

while num == "":
    num = int(input("digite um numero \n"))
    tabuada(num)

listaA = tabuada()
med = sum(listaA) / len(listaA)

for valor in listaA:
    if valor > med:
        listaB.append(valor)

print("Sua média é:" , med)
print(listaA)
print(listaB)