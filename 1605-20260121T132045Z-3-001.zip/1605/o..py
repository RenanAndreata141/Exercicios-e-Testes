# Lista de produtos disponíveis na loja
estoque_produtos = ["Celular", "Notebook", "Fones de ouvido", "Câmera"]                                                                         
carrinho = []  # Lista para armazenar os produtos escolhidos

# Exibir os produtos disponíveis
print(" Produtos disponíveis na loja:")
for produto in estoque_produtos:        
    print(f"- {produto}")

# Solicitar que o usuário escolha produtos
print("\n Adicione produtos ao seu carrinho (digite 'sair' para finalizar):")
while True:
    escolha = input("Produto: ")

    if escolha.lower() == "sair":
        break  # Sai do loop se o usuário digitar 'sair'
    
    encontrou = False
    for produto in estoque_produtos:
        if escolha.lower() == produto.lower():
            carrinho.append(produto)
            print(f"{produto} adicionado ao carrinho !")

            encontrou == True
            break

        if not encontrou:
            print("Produto não encontrado ")

print("\nProdutos no seu carrinho:?")   
for item in carrinho:
    print(f"- {item}")

print("\nCompra finalizada! Obrigado por escolher nossa loja. ")