import unicodedata

def normalizar(texto):
    texto = texto.lower()
    texto = unicodedata.normalize('NFD', texto)
    texto = ''.join(c for c in texto if unicodedata.category(c) != 'Mn')
    return texto

estoque_produtos = ["Celular", "Notebook", "Fones de ouvido", "Câmera"]
carrinho = [] 

print("Produtos disponíveis na loja:")
for produto in estoque_produtos:
    print(f"- {produto}")

print("\nAdicione produtos ao seu carrinho (digite 'sair' para finalizar):")

while True:
    escolha = input("Produto: ")
    
    if normalizar(escolha) == "sair":
        break
    
    entrada_normalizada = normalizar(escolha)
    
    produto_encontrado = None
    for produto in estoque_produtos:
        if normalizar(produto) == entrada_normalizada:
            produto_encontrado = produto
            break

    if produto_encontrado:
        carrinho.append(produto_encontrado)
        print(f"{produto_encontrado} adicionado ao carrinho!")
    else:
        print("Produto não encontrado! Escolha um da lista.")


print("\nProdutos no seu carrinho:")
for item in carrinho:
    print(f"- {item}")

print("\nCompra finalizada! Obrigado por escolher nossa loja.")
